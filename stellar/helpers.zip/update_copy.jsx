//reset GREP preferences

app.findGrepPreferences=app.changeGrepPreferences=null;

function findReplace(find, replace) {
    app.findGrepPreferences.findWhat = find;
    app.changeGrepPreferences.changeTo = replace;

    var sel = app.selection; 
    for(var n=0;n<sel.length;n++) 
    {
        sel.changeGrep();
    }
}

//reset GREP preferences

app.findGrepPreferences=app.changeGrepPreferences=null;