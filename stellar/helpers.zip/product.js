function product() {
    this.layer = "";
    this.title = "";
    this.copy = "";
    this.ours = "";
    this.theirs = "";
    this.page = "";
    this.source = "";
    this.adType = "";
    this.bursts = [];
    this.flags = [];
    this.links = [];
    this.indexes = [];
}