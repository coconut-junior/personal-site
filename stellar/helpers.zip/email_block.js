var templatePath = "/email_template.indt";
var templateFile = File(myTrimPath($.fileName)+templatePath);

const pricePattern = /\$\d+(?:\.\d+)?/g;
const titleStyle = "item head";
const burstStyle = "burst text";
const flagStyle = "flag text";
const copyStyle = "item desc";
const ourPriceStyle = "our price";
const theirsStyle = "their price";

function getRelativePath(path) {
    var scriptPath = Folder(File($.fileName).path).fsName;
    var user = scriptPath.toString().split('/')[2];
    var newPath = path.split('/');
    newPath[2] = user;
  
    return newPath.join('/');
  }

function prepDoc(myDoc) {
	// Set some defaults in case they have been changed accidentally
	myDoc.zeroPoint = [0,0];
	myDoc.viewPreferences.rulerOrigin = RulerOrigin.PAGE_ORIGIN;
	myDoc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.pixels;
	myDoc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.pixels;
	myDoc.pasteboardPreferences.pasteboardMargins = [1000,1000];
	// Import paragraph, character, and object styles from the master template
	myDoc.importStyles(ImportFormat.textStylesFormat, File(myTrimPath($.fileName)+templatePath), GlobalClashResolutionStrategy.loadAllWithOverwrite);
	myDoc.importStyles(ImportFormat.objectStylesFormat, File(myTrimPath($.fileName)+templatePath), GlobalClashResolutionStrategy.loadAllWithOverwrite);
}

function myTrimPath(myLongPath) {
	var myString = myLongPath.toString();
	var myLastSlash = myString.lastIndexOf("/");
	var myPathName = myString.slice(0,myLastSlash);
	return myPathName;
}

function ungroupAll(){
    app.activeDocument.groups.everyItem().ungroup();
}

function indexBlocks() {
    var doc = app.activeDocument;
    var items = doc.selection;
    var product1 = new product();

    //if group, take items from group
    if(items == "[object Group]"){
        items = doc.selection[0].allPageItems;
    }

    if(items.length == 0){
        alert("Please select and group a flyer product block before running this script");
        exit();
    }

    for(var i=0;i<items.length;++i){
        var p = items[i];

        product1.version = p.itemLayer.name;
    
        //is textframe
        if(p == "[object TextFrame]"){
            if(p.texts[0].appliedParagraphStyle.name.match(ourPriceStyle)
            || p.texts[0].position==Position.SUPERSCRIPT){
                product1.ours = p.texts[0].contents;
            }
            //product name
            else if (p.texts[0].appliedParagraphStyle.name.match(titleStyle)) {
                product1.title += p.texts[0].contents + " ";
            }
            //burst
            else if (p.texts[0].appliedParagraphStyle.name.match(burstStyle)){
                product1.bursts.push(p.texts[0].contents);
            }
            //flag
            else if (p.texts[0].appliedParagraphStyle.name.match(flagStyle)){
                product1.flags.push(p.texts[0].contents);
            }
            //copy
            else if(p.texts[0].appliedParagraphStyle.name.match(theirsStyle)){
                product1.theirs = p.texts[0].contents.match(pricePattern);
            }
            else if(p.texts[0].appliedParagraphStyle.name.match(copyStyle) || p.texts[0].contents.match("•")){
                var copy = fixCopy(p.texts[0].contents);
                product1.copy += copy;
            }
        }
        else{
            $.writeln(p);
        }
    
        if(p.graphics.length > 0){
            for (var g =0;g<p.graphics.length;++g){
                var link = p.graphics[g].itemLink.linkResourceURI;//linkResourceURI works for local files and CC libraries
                link = getRelativePath(link);
                product1.links.push(link);
            }
        }
    }

    //fix formatting
    product1.title = product1.title.replace("\n","").replace("  "," ");
    product1.ours = product1.ours.slice(0,product1.ours.length-2) + "." + product1.ours.slice(product1.ours.length-2,product1.ours.length);
    
    //ready, add to product array
    products.push(product1);
}

function importTemplates(){
    //import template items
    var tempDoc = app.open(templateFile);
	app.select(SelectAll.ALL);
	app.copy();
    tempDoc.close(SaveOptions.no);
    app.paste();
}

function createBlocks(products){

    var margin = 10;
    var desiredColumns = 1; //does not count 0
    var currentColumn = 0;
    var currentRow = 0;

    for (var pIndex=0;pIndex<products.length;++pIndex){
		var p = products[pIndex];
        var doc = app.activeDocument;
        
        importTemplates();
        var block = doc.groups.itemByName("email_block_template");
        var templateBounds = block.geometricBounds;
        var templateHeight = templateBounds[2] - templateBounds[0];
        var templateWidth = templateBounds[3] - templateBounds[1];
    
        var y1 = currentRow * templateHeight + (margin * currentRow);
        var x1 = currentColumn * templateWidth + (margin * currentColumn);
        var y2 = currentRow * templateHeight + templateHeight + (margin * currentRow);
        var x2 = currentColumn * templateWidth + templateWidth + (margin * currentColumn);
        block.geometricBounds = [y1,x1,y2,x2];
    
        var newBlock = block.duplicate();
        block.remove();//done with template block we have a copy
        newBlock.name = "email_block";
    
        //fill info
        var itemHead = newBlock.textFrames.itemByName("script_item_head");
        itemHead.contents = p.title;
        var itemCopy = newBlock.textFrames.itemByName("script_desc");
        itemCopy.contents = p.copy;
        var itemOurPrice = newBlock.textFrames.itemByName("script_our_price");
        itemOurPrice.contents = p.ours.replace(".","");
        var itemTheirPrice = newBlock.textFrames.itemByName("script_their_price");
        itemTheirPrice.contents = "theirs " + p.theirs.toString();
    
        //fill bursts
        for (var i = 0;i<p.bursts.length;++i){
            var itemBurst = newBlock.groups.itemByName("script_burst").textFrames.itemByName("script_burst_text_frame");
            itemBurst.contents = p.bursts[i].toString();
        }
    
        //fill flags
        for (var i = 0;i<p.flags.length;++i){
            var itemFlag = newBlock.groups.itemByName("script_flag").textFrames.itemByName("script_flag_text_frame");
            itemFlag.contents = p.flags[i].toString();
        }
    
        //remove unused burst and flag
        if(p.bursts.length == 0){
            var itemBurst = newBlock.groups.itemByName("script_burst");
            itemBurst.remove();
        }
        if(p.flags.length == 0){
            var itemFlag = newBlock.groups.itemByName("script_flag");
            itemFlag.remove();
        }
    
        for(var i=0;i<p.links.length;++i){
            try{
                //product photo
                if(p.links[i].match(".psd") && (!p.links[i].toLowerCase().match("logo"))){
                    var itemPhoto = newBlock.rectangles.itemByName("script_product");
                    itemPhoto.place(p.links[i]);
                    itemPhoto.fit(FitOptions.PROPORTIONALLY);
                }
                //logo
                else{
                    var itemLogo = newBlock.rectangles.itemByName("script_logo");
                    itemLogo.place(p.links[i]);
                    itemLogo.fit(FitOptions.PROPORTIONALLY);
                }
            }
            catch(error){
                alert("Missing link - cannot insert image :(");
            }
        }

        if(currentColumn == desiredColumns - 1){
            ++currentRow;
            currentColumn = 0;
        }
        else{
            ++currentColumn;
        }

        
	}


}