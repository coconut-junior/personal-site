#include "helpers/product.js"
#include "helpers/json2.js"
#include "helpers/json2csv.js"
#include "helpers/formatting.js"

const pricePattern = /\$\d+(?:\.\d+)?/g;
const titleStyle = "item head";
const burstStyle = "burst text";
const flagStyle = "flag text";
const copyStyle = "item desc";
const ourPriceStyle = "our price";
const theirsStyle = "their price";
const headlineStyle = "headline"

var hTolerance = 10;
var vTolerance = 10;
var database = [];
var productNames = [];
var docName = "";
var adType = "";

var scriptPath = Folder(File($.fileName).path).fsName;
var user = scriptPath.split('/')[2];
var pasteboardPath = '/Users/' + user + '/Pasteboard';
var pasteboardFolder = new Folder(pasteboardPath);

if(!pasteboardFolder.exists) {
    pasteboardFolder.create();
}

Array.prototype.includes = function(search){
	for (var i=0; i<this.length; i++)
	   if (this[i].toLowerCase() == search.toLowerCase()){
            return true;
       } 
	return false;
}

Array.prototype.indexOf = function ( item ) {
    var index = 0, length = this.length;
    for ( ; index < length; index++ ) {
        if ( this[index] === item ) {
            return index;
        }
    }

    return -1;
};

function trim(string) {
    newString = string;
    if(string[0] == ' ') {
        newString = newString.slice(1)
    }
    if(string[string.length-1] == ' ') {
        newString = newString.slice(0,-1);
    }

    return newString;
}

function getStackingIndex(doc, pageItem) {
  var pageItems = doc.pages[0].allPageItems;
  var length = pageItems.length;
  var stackIndex = 0;

  for ( var i=0; i < length; i++) {
    var loopItem = pageItems[i];
    if ( pageItem === loopItem ) {
      stackIndex = i;
      break;
    }
  }
  return stackIndex;
}

function getTimestamp() {
    var currentdate = new Date(); 
    var timestamp = (currentdate.getMonth()+1) + "/"
        + currentdate.getDate()  + "/" 
        + currentdate.getFullYear() + " @ "  
        + currentdate.getHours() + ":"  
        + currentdate.getMinutes() + ":" 
        + currentdate.getSeconds();
    return timestamp;
}

function find(array, string) {
    var result = false;
    for (var i = 0;i<array.length;++i) {
        if(array[i] == string) {
            result = true;
            break;
        }
    }
    return result;
}

function writeJson(productData) {
    var jsonFile = new File(pasteboardFolder + "/product_db.json"); 
    jsonFile.open('w');
    jsonFile.encoding = 'UTF8';
    jsonFile.write(productData);
    jsonFile.close();
}

function progress(steps) {
    var b;
    var t;
    var w;
    w = new Window("palette", "Progress", undefined, {closeButton: false});
    t = w.add("statictext");
    t.preferredSize = [450, -1]; // 450 pixels wide, default height.

    if (steps) {
        b = w.add("progressbar", undefined, 0, steps);
        b.preferredSize = [450, -1]; // 450 pixels wide, default height.
    }
    progress.close = function () {
        w.close();
    };
    progress.increment = function () {
        b.value++;
    };
    progress.message = function (message) {
        t.text = message;
    };
    w.show();
}

function getFoldersRecursive(folder) {
    var
        files = folder.getFiles(),
        editFolders = [],
        folder;

    for (var i = 0; i < files.length; i++) {
        folder = files[i];
        if (folder instanceof Folder) {
            editFolders.push(folder);
            editFolders = editFolders.concat(getFoldersRecursive(folder));
        }
    }
    return editFolders;
}


function main() {
    app.linkingPreferences.checkLinksAtOpen = false; //bypass dialogs
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;

    //find all indesign docs in all subdirectories
    var myFolder = Folder.selectDialog("Select a folder");
    var foundFiles = [];
    var docFiles = [];
    if(myFolder != null){
        var subdirectories = getFoldersRecursive(myFolder);
        subdirectories = subdirectories.concat(myFolder); //include selected folder in search

        for (var i=0;i<subdirectories.length;++i) {
            var dir = subdirectories[i];
            var files = dir.getFiles();
            if(!dir.fsName.match('digital')) {
                foundFiles = foundFiles.concat(files);
            }
        }
    }
    else {
        alert("No folder was selected, stopping the script.");
    }

    //requirements to be indexed
    for (var i=0;i<foundFiles.length;++i) {
        var file = foundFiles[i];
        if(file.name.match('.indd')) {
            if(!file.name.match("solo")) {
                if(file.name.match('page')) {
                    adType = 'flyer';
                    docFiles.push(file);
                }
                else if(file.name.match('email')){
                    adType = 'email';
                    docFiles.push(file);
                }
                
            }
        }
    }

    foundFiles = [];
    progress(docFiles.length);

    //loop through indesign docs
    for(var d = 0;d<docFiles.length;++d) {
        try {
            var doc = app.open(docFiles[d], false);
            GeneralPreference.ungroupRemembersLayers = false;
            doc.groups.everyItem().ungroup(); //ungroup everything
            var items = doc.pages[0].allPageItems;
            var whiteSpaces = [];
            var productBlocks = [];
            var productInfos = [];
            var itemIndexes = [];

            docName = docFiles[d].fsName;

            progress.increment();
            progress.message("Indexing document " + (d + 1) + " of " + docFiles.length);

            //find the white spaces!
            for (var i = 0;i<items.length;++i){
                var item = items[i];
                //sometimes these white spaces are text areas... include them
                try{
                    if((item == "[object Rectangle]" || item == "[object TextFrame]") && item.fillColor.name == "Paper"){
                        whiteSpaces.push(item);
                    }
                }
                catch(error){
                    //object is invalid
                }
            }

            //find the products!
            for (var i = 0;i<whiteSpaces.length;++i){
                var whiteSpace = whiteSpaces[i];
                productBlocks[i] = []; //clear existing products
                itemIndexes[i] = [];

                for (var p = 0;p<items.length;++p){
                    var element = items[p];
                    if(isColliding(doc,element,whiteSpace)
                    && !element.itemLayer.name.match('specs')
                    && !element.locked
                    && getStackingIndex(doc,element) < getStackingIndex(doc,whiteSpace)//exclude items under white space)
                    && (element.geometricBounds[3]-element.geometricBounds[1]) < ((doc.pages[0].bounds[3] - doc.pages[0].bounds[1]/2))/*exclude rectangles larger than product block*/
                    && element.itemLayer == whiteSpace.itemLayer){
                        productBlocks[i].push(element);
                        itemIndexes[i].push(element.id);
                    }
                }

                copyElements(doc, productBlocks[i], productInfos, itemIndexes[i]);
                //save indd for each block
            }
            
            doc.close(SaveOptions.NO);
            delete items; //IMPORTANT!!! THE GARBAGE COLLECTOR WILL NOT GET THIS!

            database = database.concat(productInfos);
            productInfos.length = 0;
            productBlocks.length = 0;
        }
        catch(e) {
            alert(e.message + " line " + e.line);
            //$.writeln("indesign doc is locked or corrupted");
        }
    }

    var data = {timestamp: getTimestamp(), products: database};
    writeJson(JSON.stringify(data, null, 4));

    //write csv
    //code needed

    app.linkingPreferences.checkLinksAtOpen = true;
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.INTERACT_WITH_ALL;
    progress.close();
}

function indexProduct(doc, newDoc, productInfos, itemIndexes) {
    var items = newDoc.allPageItems;
    var product1 = new product();
    var isBulleted = false;
    var titles = [];
    product1.indexes = itemIndexes.join(',');
    product1.adType = adType;

    for(var i=0;i<items.length;++i){
        var p = items[i];
    
        //is textframe
        if(p == "[object TextFrame]"){
            if(p.texts[0].contents.match('$') && p.texts[0].position==Position.SUPERSCRIPT){
                product1.ours = p.texts[0].contents;
                product1.ours = product1.ours.slice(0,product1.ours.length-2) + "." + product1.ours.slice(product1.ours.length-2,product1.ours.length);
                product1.ours = product1.ours.replace("\ufeff","");
            }
            //product name
            else if (p.texts[0].appliedParagraphStyle.name.match(titleStyle)
            || p.texts[0].appliedFont.name == 'ollies solid V2') {
                var title = p.texts[0].contents.toString();

                while(title.match('\n')){title = title.replace('\n',' ')}
                while(title.match('\r')){title = title.replace('\r',' ')}
                while(title.match('EACH')){title = title.replace('EACH','')}
                while(title.match('E A C H')){title = title.replace('E A C H','')}
                while(title.match('YOURCHOICE')){title = title.replace('YOURCHOICE','')}
                while(title.match('YOUR CHOICE')){title = title.replace('YOUR CHOICE','')}
                while(title.match('  ')){title = title.replace('  ',' ')} //double space

                if(title != "" && !titles.includes(trim(title))){
                    titles.push(trim(title));
                }
            }
            //burst
            else if (p.texts[0].appliedParagraphStyle.name.match(burstStyle)){
                if(!product1.bursts.includes(p.texts[0].contents)) {
                    product1.bursts.push(p.texts[0].contents);
                }
            }
            //flag
            else if (p.texts[0].appliedParagraphStyle.name.match(flagStyle)){
                if(!product1.flags.includes(p.texts[0].contents)) {
                    product1.flags.push(p.texts[0].contents);
                }
            }
            //copy
            else if(p.texts[0].appliedParagraphStyle.name.match(theirsStyle) || p.texts[0].contents.match('theirs')){
                try{product1.theirs = p.texts[0].contents.match(pricePattern).toString();}catch(e){$.writeln("no theirs price");}
            }
            else if(p.texts[0].appliedParagraphStyle.name.match(copyStyle) || p.texts[0].contents.match("•")){
                var copy = p.texts[0].contents;
                if(!product1.copy.toLowerCase().match(copy.toLowerCase())) {
                    product1.copy += copy;
                }
                if(!p.texts[0].contents.match('•')) {
                    isBulleted = true;
                }
            }
            else if (p.label == "product_version") {
                product1.layer = p.texts[0].contents;
            }
            else if (p.label == "product_page") {
                product1.page = p.texts[0].contents.replace(".indd","");
            }
        }
    }

    //if bulvar char exists, not actually bulleted
    product1.copy = fixCopy(product1.copy, isBulleted);
    product1.title = titles.join(', ');
    //remove repeat product name
    if(titles.length >= 2 && titles[0].toLowerCase().match(titles[1].toLowerCase())) {
        product1.title = product1.title.replace(', ' + titles[1],'');
    }

    //no product name! get it from the item link!
    var graphics = newDoc.allGraphics;
    var brand = "";

    for(var i=0;i<graphics.length;++i) {
        var g = graphics[i];
        var linkName = "";

        try {
            linkName = g.itemLink.linkResourceURI;
        }
        catch(e){$.writeln("there was no link");}

        //include brand name if logo is present
        if(linkName.match(".ai") || linkName.match('logo')) {
            brand = linkName.split('/')[linkName.split('/').length-1];
            brand = brand.replace('.psd','').replace('.ai','').replace('.jpg','').replace('.jpeg','');
            if(brand.match('_')) {
                brand = brand.split('_')[0];
            }
            brand = brand + " ";
        }

        //save all links
        try {
            product1.links.push(g.itemLink.linkResourceURI);
        }
        catch(e) {$.writeln("link is undefined");}
    }

    if(!product1.title.toLowerCase().match(brand)) {
        product1.title = brand + product1.title;
    }
    product1.title = fixTitle(product1.title);
    product1.source = docName;
    //do not add duplicates
    if(!find(productNames, product1.title)) {
        //do not add unless there is an ours price
        if(product1.title != "" && product1.ours != "" && product1.links != []) {
            productInfos.push(product1);
            productNames.push(product1.title);
        }
    }
}

function copyElements(doc, block, productInfos, itemIndexes) {

    var newDoc = app.documents.add();
    newDoc.viewPreferences.horizontalMeasurementUnits = doc.viewPreferences.horizontalMeasurementUnits;
    newDoc.viewPreferences.verticalMeasurementUnits = doc.viewPreferences.verticalMeasurementUnits;
    var productVersion = "";
    var productPage = ""; //format is x_x_x_page_x or page_x
    try {
        if(block.length > 0) {
            productVersion = block[0].itemLayer.name;
            //parse document path and get product page from it
            productPage = docName.split('/');
            productPage = productPage[productPage.length-1];
            
            if(productPage.match('page')) {
                productPage = productPage.split('_');
                productPage = productPage[productPage.indexOf('page')+1];
                productPage = productPage.replace(".indd","");
            }
        }

    }
    catch(e) {
        //alert(e.message + '\n' + e.line);
    }

    var productMeta1 = newDoc.pages[0].textFrames.add({label: "product_version", contents: productVersion, textFramePreferences: {autoSizingType: AutoSizingTypeEnum.HEIGHT_AND_WIDTH}});
    var productMeta2 = newDoc.pages[0].textFrames.add({label: "product_page", contents: productPage, textFramePreferences: {autoSizingType: AutoSizingTypeEnum.HEIGHT_AND_WIDTH}});

    //copy elements to new document
    for (var i = block.length -1; i > -1; --i){
        var element = block[i];
        if(!element.locked) {
            var elementCopy = element.duplicate(newDoc.pages[0]);
            if(elementCopy == "[object TextFrame]" && elementCopy.paragraphs.length >= 0) {
                //elementCopy.paragraphs[0].appliedConditions = element.paragraphs[0].appliedConditions;
                elementCopy.textFramePreferences.properties = element.textFramePreferences.properties;
            }
            elementCopy.geometricBounds = element.geometricBounds;
        }
    }

    indexProduct(doc, newDoc,productInfos, itemIndexes);
    newDoc.close(SaveOptions.NO);
}

function isColliding(doc, child, parent) {
    //y1 x1 y2 x2
    var childBounds = child.visibleBounds;
    var parentBounds = parent.visibleBounds;

    if(doc.viewPreferences.horizontalMeasurementUnits == MeasurementUnits.inches) {
        hTolerance = 0.1; //0.1 inches seems to be the sweet spot
        if(child == "[object Rectangle]" && child.graphics.length > 0) {
            hTolerance = 0.3;
        }
    }
    else if(doc.viewPreferences.horizontalMeasurementUnits = MeasurementUnits.pixels){
        hTolerance = 20;
    }

    if(doc.viewPreferences.verticalMeasurementUnits == MeasurementUnits.inches) {
        vTolerance = 0.1; //0.1 inches seems to be the sweet spot
        if(child == "[object Rectangle]" && child.graphics.length > 0) {
            vTolerance = 0.3;
        }
    }
    else if(doc.viewPreferences.verticalMeasurementUnits = MeasurementUnits.pixels){
        vTolerance = 20;
    }

    if(childBounds[0] > parentBounds[0] - vTolerance
    && childBounds[1] > parentBounds[1] - hTolerance
    && childBounds[2] < parentBounds[2] + vTolerance
    && childBounds[3] < parentBounds[3] + hTolerance ){
        return true;
    }
    else {
        return false;
    }
}

main();

