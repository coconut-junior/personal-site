var myDoc = app.activeDocument;
myDoc.textPreferences.typographersQuotes=false; //these are a bitch

var replacements = [
    {f:"”",r:"\""},
    {f:"\"x",r:"\" x "},
    {f:" in. ",r:"\""},
    {f:" feet",r:" ft."},
    {f:" pack ",r:" pk. "},
    {f:" ounce ",r:" oz. "},
    {f:" pound ",r:" lb. "},
    {f:" count ",r:" ct. "},
    {f:" gallon ",r:" gal. "}
];

for(var i = 0; i < replacements.length; i++){
    app.findGrepPreferences = app.changeGrepPreferences = null;
    app.findChangeGrepOptions = NothingEnum.nothing;
    app.findGrepPreferences.findWhat = replacements[i]['f'];
    app.changeGrepPreferences.changeTo = replacements[i]['r'];
    myDoc.changeGrep();
}