String.prototype.insert = function(index, string) {
    if (index > 0) {
        return this.substring(0, index) + string + this.substring(index);
    }

    return string + this;
};

//backport replaceall function to es3
String.prototype.replaceAll = function(str1, str2, ignore) 
{
    return this.replace(new RegExp(str1.replace(/([\/\,\!\\\^\$\{\}\[\]\(\)\.\*\+\?\|\<\>\-\&])/g,"\\$&"),(ignore?"gi":"g")),(typeof(str2)=="string")?str2.replace(/\$/g,"$$$$"):str2);
}

function titleCase(str) {
    str = str.toLowerCase();
    str = str.split(' ');
    for (var i = 0; i < str.length; i++) {
      str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1); 
    }
    return str.join(' ');
  }

function capitalizeFirstLetter(string) {
    for(var i = 0;i<string.length;++i) {
        if(/[a-z0-9]/.test(string[i])) {
            return string.substring(0,i) + string.charAt(i).toUpperCase() + string.substring(i+1,string.length);
            break;
        }
    }
}

function removeSpaces(string){
    var formatted = string;
    while(formatted.match("  ")){
        formatted = formatted.replace("  "," ");
    }

    return formatted;
}

function normalizeAbbreviations(iname){
    //correct abbreviations
    var abbreviations = ["ct","pk","pks","pt","oz","lb","lbs","ft","yd","sqft","sq","lbs","gsm","qt"];
    for (var abbr = 0;abbr<abbreviations.length;++abbr){
        var a = abbreviations[abbr];

        if(iname.match(a + " ") && !isNaN(iname[iname.indexOf(a)-1])){
            iname = iname.replace(a + " ",a + ". ");
            var i = iname.indexOf(a + ". ");
            var c = iname[i];
            if(!iname[i-1]==" "){//missing space before abbreviation?
                iname = " " + iname.insert(i," ");
            }
        }
        else if(iname.match(" " + a + " ")){
            iname.replace(" "+a+" "," "+a+" ");
        }
    }

    //fix inch marks
    iname = iname.replaceAll("  in. "," ” ");
    iname = iname.replaceAll("”", "\"");

    //iname = fixCapitalization(iname);
    
    return iname;
}

function fixBulletChar(copy) {
    copy = copy.replaceAll('\n',' ');
    copy = copy.replaceAll('\r', ' ');
    copy = copy.replaceAll('*', '\r');
    copy = copy.replaceAll('•','\n');
    copy = copy.replaceAll('  ', ' ');

    return copy;
}

function fixBullets(copy){
    
    copy = copy.replaceAll('\n', ' ');
    copy = copy.replaceAll('  ', ' ');
    
    return copy;
}

function fixTitle(title) {
    title = title.replace('logo','');
    title = fixBullets(title);
    if(title[title.length-1] == ' '){
        title = title.slice(0, -1);
    }
    title = title.replaceAll('%20',' ');
    title = titleCase(title);
    return title;
}

function fixCopy(copy, isBulleted){
    copy = copy.replaceAll('  ',' ');
	copy = copy.replaceAll(' \r','\r');
	copy = copy.replaceAll('.\r','\r');
    copy = copy.replaceAll('\n','');
    copy = copy.replaceAll('*','');
	//remove double return
	copy = copy.replaceAll('\r\r','\r');
	if(copy[-1] == '.' || copy[-1] == ' ') {
		copy = copy.slice(0,-1);
	}
    
    return copy;
}