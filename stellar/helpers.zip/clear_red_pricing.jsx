

function main() {
    var doc = app.activeDocument;
    var items = doc.pages[0].allPageItems;

    for (var i = 0;i<items.length;++i) {
    try {
        var item = items[i];

        //our price
        if(item != undefined && item == "[object TextFrame]" &&
        ((item.paragraphs[0].contents.match('$') || item.paragraphs[0].contents.match('¢'))
        && item.texts[0].position==Position.SUPERSCRIPT)){

            item.paragraphs[0].fillColor = 'Black';
            item.fillColor = 'None';
        }
        else if (item != undefined && item == "[object Rectangle]") {
            if(item.fillColor.name == 'C=0 M=0 Y=100 K=0' && item.strokeWeight == 0) {
                item.remove();
            }
        }

    }
    catch(e) {}
    }
}

if (parseFloat(app.version) < 6)
    main();
else
    app.doScript(
        main,
        ScriptLanguage.JAVASCRIPT,
        undefined,
        UndoModes.ENTIRE_SCRIPT,
        "Make Images Proportional"
    );