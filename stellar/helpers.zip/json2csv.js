function product2CSV(jsonData) {
    var csv = "";
    var products = jsonData['products'];

    var columns = ['name','our_price','their_price'];
    for (var i = 0; i<columns.length;++i) {
        csv += columns[i];
        if(i < columns.length -1) {
            csv += ',';
        }
        else {
            csv += '\n';
        }
    }

    for (var i = 0;i<products.length;++i) {
        var product = products[i];
        
        csv += product['title'] + ',';
        csv += product['ours'] + ',';
        csv += product['theirs'];
        csv += "\n";
    }

    return csv;
}