function badgerRecord(myRecord) {
	var myResult = new Object();
	myResult.pageNumber = "";
	myResult.version = "";
	myResult.headline = "";
	myResult.itemName = "";
	myResult.logo = "";
	myResult.burst = "";
	myResult.percent = "";
	myResult.imageSource = "";
	myResult.itemDesc = "";
    myResult.story = "";
    myResult.price = "";
	myResult.specialNotes = "";
	myResult.ourPriceDollars = "";
	myResult.ourPriceCents = "";
	myResult.theirPriceDollars = "";
	myResult.theirPriceCents = "";
	myResult.myError = "";
	myResult.logoArray = [];
	myResult.pageNumber = myRecord[0]; // Column A
	// Column B
	if (myRecord[1] == "ALL") {
		myResult.version = ["5050","5100","5150"];
	}
	else {
		myResult.version = myRecord[1].split(",");
	}
	myResult.headline = myRecord[2]; // Column C
	myResult.itemName = myRecord[3]; // Column D
	myResult.logo = myRecord[4]; // Column E
	myResult.burst = myRecord[5]; // Column F
	myResult.percent = myResult.burst.match(/\d+\%/);
	if (myResult.percent) {
		myResult.percent = myResult.percent[0].slice(0,-1);
	}
	myResult.imageSource = myRecord[6]; // Column G
	myResult.itemDesc = myRecord[7]; // Column H
    myResult.story = myRecord[8]; // Column I	
	myResult.price = myRecord[10]; // Column K
	myResult.specialNotes = myRecord[11]; // Column L
	myResult.sku = myRecord[14]; // Column O
	var myPriceArray = myParsePrice(myResult.price);
	myResult.ourPriceDollars = myPriceArray[0];
	myResult.ourPriceCents = myPriceArray[1];
	myResult.theirPriceDollars = myPriceArray[2];
	myResult.theirPriceCents = myPriceArray[3];
	if (myResult.logo.length > 0) {
		myResult.logoArray = myResult.logo.split(",");
	}
	return myResult;
}