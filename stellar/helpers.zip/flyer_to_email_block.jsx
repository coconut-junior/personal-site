#script "Convert Flyer to Email Block"
#include "helpers/product.js"
#include "helpers/formatting.js"
#include "helpers/email_block.js"

var doc = app.activeDocument;
var products = [];

//ungroupAll();
prepDoc(doc);
indexBlocks();
importTemplates();
createBlocks(products);

