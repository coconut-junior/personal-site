﻿//DESCRIPTION:Prepare individual products in a flyer for export

// Modified 2020-06-30
// Keith Gilbert, Gilbert Consulting
// http://www.gilbertconsulting.com

Pre();
  
function Pre () {  
	// Check to make sure all required conditions are met
	var  
		_scriptRedraw = app.scriptPreferences.enableRedraw,  
		_userInteraction = app.scriptPreferences.userInteractionLevel;  
		_measurementUnit = app.scriptPreferences.measurementUnit;
	app.scriptPreferences.enableRedraw = false;  
	app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;  
	app.scriptPreferences.measurementUnit = MeasurementUnits.POINTS;
	if (app.selection.length == 0) {
		alert("Please select at least one object and try again.");
		return;
	}
	if (app.documents.length == 0) {
		alert("Please open a document and try again.");
		return;
	}
	app.doScript('Main();', undefined, [], UndoModes.ENTIRE_SCRIPT,"Run Script"); // This makes the script un-doable
	// Main();
	app.scriptPreferences.enableRedraw = _scriptRedraw;  
	app.scriptPreferences.userInteractionLevel = _userInteraction;  
	app.scriptPreferences.measurementUnit = _measurementUnit;
}  
function Main() {
	// Determine which poster is which
	var myDoc = app.activeDocument;
	var mySelection = app.selection;
	if ((mySelection.length > 1) && (mySelection.constructor.name != "Group")) {
		// Group the objects
		var myObject = myDoc.groups.add(mySelection);
		myObject.select(); // Need to do this otherwise all the components of the group are still selected
	}
	else {
		var myObject = mySelection[0];
	}
	myObject.name = "script_product";
}